# ClaimPilot — Multi-Agent Motor Insurance Claims Intelligence

ClaimPilot is an educational decision-support prototype that demonstrates how a multi-step AI workflow can assist a motor insurance claims team. It uses LangGraph to orchestrate specialist agent nodes, optional Gemini model calls, local policy-text retrieval, and a Streamlit dashboard.

> **Important:** This is a portfolio prototype using fictional sample data. It does not authenticate documents, determine fraud, or approve/reject claims. A qualified human claims officer must verify all findings against the real policy and evidence.

## Features

- Claim intake and structured fact extraction (Gemini optional; local fallback included)
- Policy clause retrieval using TF-IDF similarity (a simple local RAG-style retrieval step)
- Policy review grounded in retrieved excerpts
- Basic document presence and consistency checks
- Explainable risk flags
- Human-review routing and a downloadable JSON assessment
- SQLite claim history
- PDF, TXT and DOCX text extraction

## Architecture

`Streamlit UI → LangGraph workflow → Intake → Policy Retrieval/Verification → Document Checks → Risk Analysis → Report`

The agent nodes are separate workflow steps. They are orchestrated in a defined sequence; this prototype is not a collection of unconstrained autonomous agents.

## Requirements

Use Python 3.11 or 3.12 for the smoothest compatibility with the AI ecosystem.

## Setup (Windows / VS Code)

```bash
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If `py -3.11` is unavailable, install Python 3.11 or 3.12 first, then create the virtual environment with that interpreter.

## Run

```bash
streamlit run app.py
```

Open the local address shown in the terminal (usually `http://localhost:8501`).

## Optional Gemini setup

1. Create a Gemini API key from Google AI Studio.
2. Copy `.env.example` to `.env`.
3. Put the key in `.env` as `GOOGLE_API_KEY=...`.
4. Restart Streamlit.

The app also has a password field in the sidebar. Do not share your API key or commit `.env` to GitHub. The project runs without a key using a deterministic local fallback, but LLM-powered extraction and summaries will be unavailable.

## Test the demo

- Keep `data/policies/sample_motor_policy.txt` in place.
- Use the prefilled sample claim in the app.
- Click **Run ClaimPilot agents**.
- Try changing the amount or incident details and observe how the flags change.
- Optionally upload PDF/TXT/DOCX supporting documents.

## Current limitations

- TF-IDF retrieval is a lightweight local demonstration, not a production-grade vector database.
- Document checks are basic keyword/presence checks and do not verify authenticity.
- The sample policy is fictional and deliberately incomplete.
- No real insurer API, payment system, customer database, or claims adjudication system is connected.
- Production deployment would require authentication, authorization, encryption, secure file storage, audit controls, robust evaluation, monitoring, and legal/compliance review.

## Suggested next improvements

- Add OCR for scanned documents.
- Replace TF-IDF with a vector database and embedding model.
- Add policy-period and deductible calculations using validated policy schedules.
- Add reviewer login, approval/rejection workflow, and immutable audit logs.
- Add automated tests and evaluation datasets.

## GitHub publishing

Create a **public** repository named `ClaimPilot-Multi-Agent-Insurance-Claims`. Upload the project files (not your `.env`, virtual environment, or database). See `GITHUB_UPLOAD_GUIDE.md`.

## Disclaimer

For educational and portfolio demonstration only. Not insurance, legal, financial, or fraud-detection advice.
