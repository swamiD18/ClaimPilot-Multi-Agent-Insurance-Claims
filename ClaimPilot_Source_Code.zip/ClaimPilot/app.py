import os
import json
import streamlit as st
from dotenv import load_dotenv
from claimpilot.workflow import run_claim_workflow
from claimpilot.documents import extract_text, load_policy_texts
from claimpilot.database import init_db, save_claim, list_claims

load_dotenv()
st.set_page_config(page_title="ClaimPilot", page_icon="🛡️", layout="wide")
init_db()

st.title("🛡️ ClaimPilot")
st.caption("Multi-Agent Motor Insurance Claims Intelligence — decision support for human claims officers")

with st.sidebar:
    st.header("Configuration")
    api_key = st.text_input("Gemini API key (optional)", type="password",
                            value=os.getenv("GOOGLE_API_KEY", ""))
    st.caption("Without an API key, ClaimPilot uses its local rule-based fallback for extraction and analysis.")
    st.divider()
    st.subheader("Sample data")
    st.write("Sample policy documents are stored in `data/policies/`.")

tab1, tab2 = st.tabs(["Process a claim", "Claim history"])

with tab1:
    st.subheader("1. Enter claim information")
    col1, col2 = st.columns(2)
    with col1:
        claim_id = st.text_input("Claim reference", value="CLM-1001")
        policy_number = st.text_input("Policy number", value="MOTOR-2026-001")
        claimant = st.text_input("Claimant name", value="Aarav Sharma")
        incident_date = st.text_input("Incident date (YYYY-MM-DD)", value="2026-11-20")
    with col2:
        claim_amount = st.number_input("Claim amount (INR)", min_value=0.0, value=45000.0, step=1000.0)
        incident_type = st.selectbox("Incident type", ["Accident", "Theft", "Fire", "Other"])
        vehicle = st.text_input("Vehicle details", value="Maruti Swift, 2022")
        location = st.text_input("Incident location", value="Pune, Maharashtra")

    incident_description = st.text_area(
        "Describe what happened",
        value="The car was involved in a collision at a road junction. The front bumper and headlamp were damaged."
    )
    uploaded_docs = st.file_uploader(
        "Upload supporting documents (PDF, TXT, DOCX)",
        type=["pdf", "txt", "docx"], accept_multiple_files=True
    )
    policy_uploads = st.file_uploader(
        "Optional: upload policy documents (PDF, TXT, DOCX)",
        type=["pdf", "txt", "docx"], accept_multiple_files=True, key="policies"
    )

    if st.button("Run ClaimPilot agents", type="primary", use_container_width=True):
        docs = []
        for f in uploaded_docs or []:
            try:
                docs.append({"name": f.name, "text": extract_text(f.name, f.getvalue())})
            except Exception as e:
                docs.append({"name": f.name, "text": "", "error": str(e)})

        policies = load_policy_texts()
        for f in policy_uploads or []:
            try:
                policies.append({"name": f.name, "text": extract_text(f.name, f.getvalue())})
            except Exception:
                pass

        claim = {
            "claim_id": claim_id, "policy_number": policy_number,
            "claimant": claimant, "incident_date": incident_date,
            "claim_amount": claim_amount, "incident_type": incident_type,
            "vehicle": vehicle, "location": location,
            "incident_description": incident_description
        }
        with st.spinner("Agents are reviewing the claim..."):
            result = run_claim_workflow(claim, docs, policies, api_key or None)
        st.session_state["last_result"] = result
        save_claim(claim_id, claim, result)

    result = st.session_state.get("last_result")
    if result:
        st.divider()
        st.subheader("2. Claim assessment")
        a, b, c = st.columns(3)
        a.metric("Risk level", result.get("risk_level", "Needs review"))
        b.metric("Document status", result.get("document_status", "Unknown"))
        c.metric("Recommended route", result.get("routing", "Human review"))
        st.info("This is an AI-assisted preliminary assessment, not an insurance decision.")
        st.markdown("### Claim intake")
        st.json(result.get("intake", {}))
        st.markdown("### Policy verification")
        st.write(result.get("policy_verification", ""))
        st.markdown("### Document verification")
        st.write(result.get("document_verification", ""))
        st.markdown("### Risk analysis")
        st.write(result.get("risk_analysis", ""))
        st.markdown("### Recommended next action")
        st.write(result.get("recommendation", ""))
        st.markdown("### Supporting policy excerpts")
        for item in result.get("policy_evidence", []):
            with st.expander(item.get("source", "Policy excerpt")):
                st.write(item.get("text", ""))
        st.markdown("### Audit trail")
        st.write(" → ".join(result.get("agent_trace", [])))
        st.download_button(
            "Download assessment JSON",
            data=json.dumps(result, indent=2, ensure_ascii=False),
            file_name=f"{claim_id}_assessment.json",
            mime="application/json"
        )

with tab2:
    st.subheader("Previously processed claims")
    rows = list_claims()
    if not rows:
        st.write("No claims have been processed yet.")
    else:
        for row in rows:
            with st.expander(f'{row["claim_id"]} — {row["created_at"]}'):
                st.json(row["result"])
