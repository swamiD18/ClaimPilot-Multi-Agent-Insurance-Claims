# Publish ClaimPilot to GitHub (Windows)

## Before uploading
1. Run the project locally and test it.
2. Make sure your API key is not in any source file.
3. Do not upload `.env`, `.venv`, `venv`, or `claimpilot.db`.
4. Keep `.gitignore` in the root folder.

## Option A — GitHub website (easiest)
1. Sign in at https://github.com
2. Click **New repository**.
3. Repository name: `ClaimPilot-Multi-Agent-Insurance-Claims`
4. Choose **Public**.
5. Do not initialize with a README (this project already has one).
6. Create the repository.
7. In the repository page choose **Add file → Upload files**.
8. Open the extracted `ClaimPilot` folder and drag its contents into the upload area. Include folders such as `claimpilot` and `data`.
9. Commit the upload.
10. Copy the repository URL, for example `https://github.com/YOUR-USERNAME/ClaimPilot-Multi-Agent-Insurance-Claims`.

## Option B — Git commands
Open VS Code terminal in the project folder and run:

```bash
git init
git add .
git status
```

Check that `.env`, `.venv`, and `claimpilot.db` are NOT listed. Then:

```bash
git commit -m "Build ClaimPilot multi-agent insurance claims prototype"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/ClaimPilot-Multi-Agent-Insurance-Claims.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your actual GitHub username. GitHub may ask you to authenticate.

## Final check
Open the repository in a private/incognito browser window. Confirm that the README and source folders are visible. Copy the real public URL into the company form.

**Do not paste a made-up or not-yet-created repository URL into the company form.**
