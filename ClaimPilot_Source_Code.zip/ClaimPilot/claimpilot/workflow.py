from typing import TypedDict, Any
from langgraph.graph import StateGraph, END
from .agents import (
    claim_intake_agent, policy_verification_agent, document_verification_agent,
    risk_analysis_agent, report_agent
)

class ClaimState(TypedDict, total=False):
    claim: dict
    documents: list
    policies: list
    api_key: str
    intake: dict
    policy_text: str
    policy_evidence: list
    document_result: dict
    risk_result: dict
    result: dict
    trace: list

def intake_node(state):
    intake = claim_intake_agent(state["claim"], state.get("documents", []), state.get("api_key"))
    return {"intake": intake, "trace": state.get("trace", []) + ["Claim Intake Agent"]}

def policy_node(state):
    text, evidence = policy_verification_agent(
        state["claim"], state["intake"], state.get("policies", []), state.get("api_key")
    )
    return {"policy_text": text, "policy_evidence": evidence,
            "trace": state.get("trace", []) + ["Policy Verification Agent"]}

def documents_node(state):
    result = document_verification_agent(
        state["claim"], state["intake"], state.get("documents", [])
    )
    return {"document_result": result, "trace": state.get("trace", []) + ["Document Verification Agent"]}

def risk_node(state):
    result = risk_analysis_agent(
        state["claim"], state["intake"], state["document_result"],
        state.get("policy_evidence", []), state.get("api_key")
    )
    return {"risk_result": result, "trace": state.get("trace", []) + ["Risk Analysis Agent"]}

def report_node(state):
    result = report_agent(
        state["claim"], state["intake"], state["policy_text"],
        state["document_result"], state["risk_result"]
    )
    result["policy_evidence"] = state.get("policy_evidence", [])
    result["agent_trace"] = state.get("trace", []) + ["Claim Report Agent"]
    return {"result": result}

def build_graph():
    graph = StateGraph(ClaimState)
    graph.add_node("intake", intake_node)
    graph.add_node("policy", policy_node)
    graph.add_node("documents", documents_node)
    graph.add_node("risk", risk_node)
    graph.add_node("report", report_node)
    graph.set_entry_point("intake")
    graph.add_edge("intake", "policy")
    graph.add_edge("policy", "documents")
    graph.add_edge("documents", "risk")
    graph.add_edge("risk", "report")
    graph.add_edge("report", END)
    return graph.compile()

def run_claim_workflow(claim, documents, policies, api_key=None):
    app = build_graph()
    state = {
        "claim": claim, "documents": documents, "policies": policies,
        "api_key": api_key or "", "trace": []
    }
    final_state = app.invoke(state)
    return final_state["result"]
