import json
import sqlite3
from pathlib import Path
from datetime import datetime, timezone

DB_PATH = Path(__file__).resolve().parent.parent / "claimpilot.db"

def _connect():
    return sqlite3.connect(DB_PATH)

def init_db():
    with _connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS claims (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                claim_id TEXT NOT NULL,
                claim_json TEXT NOT NULL,
                result_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)

def save_claim(claim_id, claim, result):
    with _connect() as conn:
        conn.execute(
            "INSERT INTO claims (claim_id, claim_json, result_json, created_at) VALUES (?, ?, ?, ?)",
            (claim_id, json.dumps(claim), json.dumps(result), datetime.now(timezone.utc).isoformat())
        )

def list_claims():
    with _connect() as conn:
        rows = conn.execute(
            "SELECT claim_id, result_json, created_at FROM claims ORDER BY id DESC LIMIT 50"
        ).fetchall()
    return [{"claim_id": r[0], "result": json.loads(r[1]), "created_at": r[2]} for r in rows]
