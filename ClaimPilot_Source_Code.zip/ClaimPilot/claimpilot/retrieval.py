from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def retrieve_policy_evidence(question: str, policy_docs: list, top_k: int = 3):
    chunks, sources = [], []
    for doc in policy_docs:
        text = doc.get("text", "")
        # A simple paragraph-based chunker keeps this demo transparent and easy to inspect.
        for paragraph in [p.strip() for p in text.split("\n\n") if p.strip()]:
            chunks.append(paragraph)
            sources.append(doc.get("name", "Policy document"))
    if not chunks:
        return []
    try:
        matrix = TfidfVectorizer(stop_words="english").fit_transform([question] + chunks)
        scores = cosine_similarity(matrix[0:1], matrix[1:]).flatten()
        indexes = scores.argsort()[::-1][:top_k]
        return [{"source": sources[i], "text": chunks[i], "score": round(float(scores[i]), 3)}
                for i in indexes if scores[i] > 0]
    except ValueError:
        return []
