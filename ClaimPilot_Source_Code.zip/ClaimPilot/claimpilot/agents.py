import json
import re
from langchain_google_genai import ChatGoogleGenerativeAI
from .retrieval import retrieve_policy_evidence

def _llm(api_key):
    if not api_key:
        return None
    try:
        return ChatGoogleGenerativeAI(
            model="gemini-2.5-flash",
            google_api_key=api_key,
            temperature=0.1
        )
    except Exception:
        return None

def _ask_json(llm, prompt):
    if not llm:
        return None
    try:
        response = llm.invoke(prompt)
        raw = response.content if hasattr(response, "content") else str(response)
        raw = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.MULTILINE).strip()
        return json.loads(raw)
    except Exception:
        return None

def claim_intake_agent(claim, documents, api_key):
    llm = _llm(api_key)
    docs_text = "\n".join(d.get("text", "")[:3000] for d in documents)
    prompt = f"""Extract claim facts as JSON only. Keys: claimant, policy_number, incident_date,
claim_amount, incident_type, vehicle, location, key_facts, inconsistencies.
Do not invent missing facts; use null or empty arrays.
Claim form: {json.dumps(claim)}
Supporting document text: {docs_text[:7000]}"""
    extracted = _ask_json(llm, prompt)
    if not extracted:
        extracted = {
            "claimant": claim.get("claimant"),
            "policy_number": claim.get("policy_number"),
            "incident_date": claim.get("incident_date"),
            "claim_amount": claim.get("claim_amount"),
            "incident_type": claim.get("incident_type"),
            "vehicle": claim.get("vehicle"),
            "location": claim.get("location"),
            "key_facts": [claim.get("incident_description", "")],
            "inconsistencies": []
        }
    return extracted

def policy_verification_agent(claim, intake, policies, api_key):
    query = (
        f"Does this policy cover {claim.get('incident_type')} for a motor vehicle? "
        f"Find relevant coverage, exclusions, policy period, claim limits, and conditions. "
        f"Policy number {claim.get('policy_number')}."
    )
    evidence = retrieve_policy_evidence(query, policies, top_k=4)
    llm = _llm(api_key)
    prompt = f"""You are a cautious insurance policy review assistant.
Use ONLY the evidence below. Do not assume a clause exists if it is not shown.
State what the excerpts appear to say, what is unknown, and what a human officer must verify.
Do not approve or reject the claim.
Claim: {json.dumps(claim)}
Retrieved policy excerpts: {json.dumps(evidence)}
Return concise plain text."""
    answer = None
    if llm and evidence:
        try:
            answer = llm.invoke(prompt).content
        except Exception:
            pass
    if not answer:
        if evidence:
            answer = ("Relevant policy text was retrieved. A human officer must verify the policy "
                      "number, dates, coverage conditions, exclusions, and limits against the full policy.")
        else:
            answer = ("No sufficiently relevant policy excerpt was found. Upload the applicable policy "
                      "document and ask a human officer to verify coverage.")
    return answer, evidence

def document_verification_agent(claim, intake, documents):
    names = [d.get("name", "").lower() for d in documents]
    text = " ".join(d.get("text", "").lower() for d in documents)
    required = ["claim form", "repair estimate or invoice", "vehicle registration", "driving licence"]
    found, missing = [], []
    for item in required:
        key = item.split()[0]
        if key in " ".join(names) or key in text:
            found.append(item)
        else:
            missing.append(item)
    issues = []
    if not documents:
        issues.append("No supporting documents were uploaded.")
    if not claim.get("policy_number"):
        issues.append("Policy number is missing.")
    if not claim.get("incident_date"):
        issues.append("Incident date is missing.")
    status = "Complete for initial review" if not missing and not issues else "Additional checks required"
    return {
        "status": status,
        "documents_found": found,
        "documents_to_request": missing,
        "issues": issues,
        "note": "This is a basic presence check; it does not authenticate documents."
    }

def risk_analysis_agent(claim, intake, doc_result, policy_evidence, api_key):
    flags = []
    amount = float(claim.get("claim_amount") or 0)
    if amount <= 0:
        flags.append("Claim amount is missing or not positive.")
    if amount >= 200000:
        flags.append("Claim amount is high and may require additional review.")
    if doc_result.get("documents_to_request"):
        flags.append("Some expected supporting documents appear to be missing.")
    if intake.get("inconsistencies"):
        flags.extend([f"Possible inconsistency: {x}" for x in intake["inconsistencies"]])
    if not policy_evidence:
        flags.append("Policy evidence was not found in the uploaded/sample policy documents.")
    if not flags:
        flags.append("No basic rule-based risk flags detected; this does not mean the claim is risk-free.")
    llm = _llm(api_key)
    prompt = f"""Review these preliminary claim facts and flags. Identify only explainable inconsistencies
or missing information. Never accuse anyone of fraud and do not make an approval decision.
Claim: {json.dumps(claim)}
Existing flags: {json.dumps(flags)}
Return 2-4 concise sentences."""
    extra = None
    if llm:
        try:
            extra = llm.invoke(prompt).content
        except Exception:
            pass
    return {"flags": flags, "additional_analysis": extra or "Rule-based preliminary checks completed."}

def report_agent(claim, intake, policy_text, doc_result, risk_result):
    flags = risk_result.get("flags", [])
    risk_level = "High review priority" if len(flags) >= 3 else ("Medium review priority" if len(flags) == 2 else "Standard review")
    recommendation = (
        "Route to a human claims officer. Review the policy evidence, request missing documents, "
        "and resolve all flagged inconsistencies before making any decision."
    )
    routing = "Specialist human review" if risk_level == "High review priority" else "Human claims officer"
    return {
        "claim_id": claim.get("claim_id"),
        "risk_level": risk_level,
        "document_status": doc_result.get("status"),
        "routing": routing,
        "intake": intake,
        "policy_verification": policy_text,
        "document_verification": doc_result,
        "risk_analysis": risk_result,
        "recommendation": recommendation,
        "disclaimer": "Decision-support prototype only. No automated claim approval, rejection, or fraud determination."
    }
