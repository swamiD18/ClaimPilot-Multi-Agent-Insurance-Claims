from io import BytesIO
from pathlib import Path

POLICY_DIR = Path(__file__).resolve().parent.parent / "data" / "policies"

def extract_text(filename: str, content: bytes) -> str:
    suffix = Path(filename).suffix.lower()
    if suffix == ".pdf":
        from pypdf import PdfReader
        reader = PdfReader(BytesIO(content))
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    if suffix == ".docx":
        from docx import Document
        doc = Document(BytesIO(content))
        return "\n".join(p.text for p in doc.paragraphs)
    return content.decode("utf-8", errors="ignore")

def load_policy_texts():
    POLICY_DIR.mkdir(parents=True, exist_ok=True)
    items = []
    for path in POLICY_DIR.glob("*.txt"):
        items.append({"name": path.name, "text": path.read_text(encoding="utf-8")})
    return items
