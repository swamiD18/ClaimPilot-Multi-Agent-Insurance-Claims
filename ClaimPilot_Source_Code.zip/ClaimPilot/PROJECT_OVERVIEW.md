# ClaimPilot project overview

This repository contains a runnable educational MVP. It is designed to be extended, tested, and explained honestly in a placement interview. The workflow currently has five sequential LangGraph nodes: intake, policy verification, document verification, risk analysis, and report generation.
