from claimpilot.retrieval import retrieve_policy_evidence

def test_retrieval_returns_matching_policy_text():
    docs = [{"name": "policy.txt", "text": "Accidental physical damage to the insured vehicle may be covered.\n\nWear and tear is excluded."}]
    results = retrieve_policy_evidence("accidental vehicle damage cover", docs)
    assert results
    assert "Accidental" in results[0]["text"]
